#include <stdio.h>
#include <iostream>

#include <time.h>
#include <cassert>

#include <random>

typedef unsigned uint;

static std::mt19937 gen(42);

extern "C" void cshaw(double *coeffs,int n,double *xs,double *ys,int m);

template<typename T>
T*
allocateRandArray(int n) {
 std::uniform_real_distribution<double> dRand;

  T * A = new T[n];
  for (int i = 0; i < n; ++i) {
    A[i] = dRand(gen);
  }
  return A;
}

uint64_t
hashArray(double * A, int n, uint64_t carry) {
  uint64_t accu = carry;
  for (int i = 0; i < n; ++i) {
    accu = accu * 101 + *(uint64_t*)(A + i);
  }
  return accu;
}

int main(int argc, char ** argv) {
  const unsigned m = 2048*1024;
  const unsigned n = 2048;

  double * coeffs = allocateRandArray<double>(n);
  double * xs = allocateRandArray<double>(m);
  double * ys = allocateRandArray<double>(m);

  // compute checksum
  uint64_t startHash = hashArray(coeffs, n, 0);
  startHash = hashArray(xs, m, startHash);
  startHash = hashArray(ys, m, startHash);

  auto startTime = clock();
  cshaw(coeffs, n, xs, ys, m);
  auto endTime = clock();

  double runTime = ((endTime - startTime) / (double) CLOCKS_PER_SEC);

  // compute checksum
  uint64_t endHash = hashArray(coeffs, n, 0);
  endHash = hashArray(xs, m, endHash);
  endHash = hashArray(ys, m, endHash);

  std::cerr
     << "Time     " << runTime << "\n"
     << "PreHash  " << startHash << "\n"
     << "PostHash " << endHash << "\n";

  for (int i : {0, 42, 31, 97, 379, 496, 1031, 2011}) {
    std::cerr << "Sample " << i << " : " << ys[i] << "\n";
  }

  delete [] coeffs;
  delete [] xs;
  delete [] ys;

  return 0;
}
