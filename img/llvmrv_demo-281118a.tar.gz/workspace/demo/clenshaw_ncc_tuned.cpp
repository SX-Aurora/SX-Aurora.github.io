/*
  [focht@aurora0 demo]$ ./cshaw.ncc.bin 
  Time 1.59206
  Hash 8207546301339025925
*/
#define min(a,b) ((a) < (b) ? (a) : (b))
extern "C"
void
cshaw(double *coeffs, int n, double *xs, double *ys, int m)
{
  double u0[256], u1[256], u2[256];

  #pragma _NEC vreg(u0) 
  #pragma _NEC vreg(u1) 
  #pragma _NEC vreg(u2) 
  //#pragma omp simd safelen(256)
  for (int i = 0; i < m; i+=256) {
    int mm = min(256, m - i);
    #pragma _NEC ivdep
    for (int j = 0; j < mm; j++) {
      u0[j] = 0; u1[j] = 0; u2[j] = 0;
    }
    for (int k = n; k >= 0; k--) {
    #pragma _NEC ivdep
      for (int j = 0; j < mm; j++) {
        u2[j] = u1[j];
        u1[j] = u0[j];
        u0[j] = 2*xs[j+i]*u1[j]-u2[j]+coeffs[k];
      }
    }
    #pragma _NEC ivdep
    for (int j = 0; j < mm; j++) {
      ys[j+i] += 0.5*(coeffs[0]+u0[j]-u2[j]);
    }
  }
}
