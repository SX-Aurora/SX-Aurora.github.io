# execute this in "scl enable devtoolset-7 bash

source scripts/setup_env.sh

echo "===== Updating LLVM-VE + RV ====="

# check if LLVM is available at all
if [ ! -d ${ENV_ROOT}/llvm ]; then
  echo "ERROR! Could not find LLVM-VE. Run ./scripts/bootstrap.sh first."
  exit
fi


# if so, update
cd ${ENV_ROOT}/llvm
git pull
git submodule update --recursive

cd ${ENV_ROOT}/llvm_build && ninja
cd ${ENV_ROOT}

echo "===== LLVM-VE + RV update completed! ====="
