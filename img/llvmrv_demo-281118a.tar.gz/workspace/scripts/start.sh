#! /usr/bin/env bash

export http_proxy=10.0.0.200:3128
export https_proxy=${http_proxy}
export ftp_proxy=${http_proxy}

scl enable devtoolset-7 bash

