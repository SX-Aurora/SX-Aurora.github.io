#!/usr/bin/env bash

echo "Setting up the ENV_ROOT prefix and VE environment."

LIBS=/opt/nec/ve/lib64
INCS=/opt/nec/ve/include

export PATH=${PATH}:/opt/nec/ve/bin

export LIBRARY_PATH=${LIBS}:${LIBRARY_PATH}
export LD_LIBRARY_PATH=${LIBS}:${LD_LIBRARY_PATH}

export CPATH=${INCS}:${CPATH}


### setup_env.sh ###
ENV_ROOT=`realpath $(dirname -- "$BASH_SOURCE")/..`
        
ENV_INSTALL=${ENV_ROOT}/install
        
ENV_DOWNLOADS=${ENV_ROOT}/downloads
        
# build directory for auxiliary tools (cmake, ninja)
ENV_BUILD=${ENV_ROOT}/build
        
### configure common paths ###
export CPATH=${ENV_INSTALL}/include:${CPATH}
export LD_LIBRARY_PATH=${ENV_INSTALL}/lib:${LD_LIBRARY_PATH}
export LD_RUN_PATH=${ENV_INSTALL}/lib:${LD_RUN_PATH}
export LIBRARY_PATH=${ENV_INSTALL}/lib:${LIBRARY_PATH}
export CMAKE_MODULE_PATH=${ENV_INSTALL}/share
export PATH=${ENV_INSTALL}/bin:${ENV_ROOT}/llvm/scripts:${PATH}
        
export PKG_CONFIG_PATH=${ENV_INSTALL}/lib/pkgconfig:${PKG_CONFIG_PATH}
        
export JOBS=24

export PATH=${ENV_ROOT}/llvm_build/bin:${PATH}
export LD_LIBRARY_PATH=${ENV_ROOT}/llvm_build/lib:${LD_LIBRARY_PATH}


#### RV diagnostic options ####
export RV_REPORT=1
