# execute this in "scl enable devtoolset-7 bash

source scripts/setup_env.sh

echo "Bootstrapping workspace for LLVM-VE + RV"

### toolbox ###
# enter path $1, creating the path if necessary
function goto_dir {
  mkdir -p $1 && cd $1
}


# download URL at $1 and return the destination file name.
function download_file {
  wget -nv $1 2>&1 |cut -d\" -f2
}

# fetch the archive at $2 and extract it into the path $1. Be at path $1 on return.
function fetch_and_extract {
  DEST=$1
  URL=$2

  echo "Downloading ${URL}"

  # download
  goto_dir ${ENV_DOWNLOADS}
  ARCHIVE=${ENV_DOWNLOADS}/`download_file ${URL}`

  # unpack
  goto_dir ${DEST}
  tar -xf ${ARCHIVE}
}


### bootstrap.sh ###
# installs a more up-to-date developer prefix

### fetch and installr re2c ###
fetch_and_extract ${ENV_BUILD}/re2c https://github.com/skvadrik/re2c/releases/download/1.1.1/re2c-1.1.1.tar.gz
cd re2c-1.1.1
./configure --prefix=${ENV_INSTALL}
make -j ${JOBS}
make install

### fetch and install ninja ###
fetch_and_extract ${ENV_BUILD}/ninja https://github.com/ninja-build/ninja/archive/v1.8.2.tar.gz
cd ninja-1.8.2
./configure.py --host=linux --platform=linux --bootstrap
cp ninja ${ENV_INSTALL}/bin


## fetch and extract libxml2 ###
fetch_and_extract ${ENV_BUILD}/libxml2 ftp://xmlsoft.org/libxml2/libxml2-2.9.8.tar.gz
cd libxml2-2.9.8
./configure --prefix=${ENV_INSTALL} --without-python
make -j ${JOBS} && make install




### fetch and build LLVM stack
cd ${ENV_ROOT}
git clone https://github.com/SXAuroraTSUBASAResearch/llvm.git -b demo_cdl
cd ${ENV_ROOT}/llvm && git submodule update --init --recursive


# build LLVM
goto_dir ${ENV_ROOT}/llvm_build
cmake3 ../llvm -G Ninja -DBUILD_SHARED_LIBS=on -DLLVM_TARGETS_TO_BUILD"=X86;VE" -DLLVM_ENABLE_CXX1Y=ON -DCMAKE_BUILD_TYPE=Debug -DCMAKE_SIZEOF_VOID_P=8
ninja
cp bin/llvm-lit ${ENV_INSTALL}/bin

cd ${ENV_ROOT}


echo "===== LLVM-VE + RV bootrapping completed! ==="
echo "Use rvclang --target=ve -O2 -fopenmp to compile C code with LLVM-VE + RV"
echo "Annotate loops with #pragma omp simd safelen(256) to trigger vectorization"
